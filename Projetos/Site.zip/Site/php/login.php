<?php
    
    $nome = $_POST['ch_nome'];
    $senha = $_POST['ch_senha'];
    $email = $_POST['ch_email'];
    $idade = $_POST['ch_idade'];
    $genero = $_POST['ch_genero'];

    $texto = file_get_contents('../txt/arquivo.txt');

    $nome_Certo = $texto[0].$texto[6].$texto[30].$texto[71];
    $senha_Certa = $texto[679].$texto[12].$texto[679].$texto[676].$texto[678].$texto[677].$texto[3].$texto[28].$texto[3].$texto[677].$texto[673].$texto[681].$texto[677].$texto[679].$texto[107].$texto[221].$texto[680].$texto[221].$texto[150].$texto[136].$texto[679].$texto[678].$texto[318].$texto[248].$texto[136].$texto[107].$texto[429].$texto[678].$texto[429].$texto[682].$texto[429].$texto[677];
    $email_Certo = $texto[239].$texto[41].$texto[114].$texto[22].$texto[109].$texto[41].$texto[71].$texto[111].$texto[105].$texto[6].$texto[30].$texto[71].$texto[672].$texto[336].$texto[114].$texto[46].$texto[336].$texto[109].$texto[111].$texto[533].$texto[109];
    $idade_certa = $texto[675].$texto[680];
    $genero_certo = $texto[59].$texto[80].$texto[381].$texto[384].$texto[609].$texto[105].$texto[6].$texto[30].$texto[71];

    if( $nome == $nome_Certo && $senha == $senha_Certa && $email == $email_Certo && $idade == $idade_certa && $genero == $genero_certo){
        echo json_encode("Cadastrado");
    }else{
        echo json_encode("Nao cadastrado");
    }
?>