function CarregarImagens(){
    window.location.href = "paginas/imagens.html"
}
function CarregarVideos(){
    window.location.href = "paginas/videos.html"
}
function CarregarLogin(){
    window.location.href = "paginas/login.html"
}
function VoltarpaginaInicial(){
    window.location.href = "../index.html";
    
}
function Hacksucesso(){
    alert('Hacker detectado     Fechando programa');
    window.location.href = "https://www.google.com.br"
}