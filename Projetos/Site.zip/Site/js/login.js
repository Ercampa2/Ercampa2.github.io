function SalvarDados(){
    let nome = $('#input-nome').val();
    let senha = $('#input-senha').val();
    let email = $('#input-email').val();
    let idade = $('#input-idade').val();
    let masculino = $('#input-masculino:checked').val();
    let feminino = $('#input-feminino:checked').val();
    let genero, existenciaGenero;


    if(masculino == 'on'){
        genero = 'masculino';
        existenciaGenero = true;
    }else if(feminino == 'on'){
        genero = 'feminino';
        existenciaGenero = true;
    }else{
        existenciaGenero = false;
    }

    if(nome != '' && senha != '' && email != '' && idade != '' && existenciaGenero){
        ComunicacaoServidor(nome, senha, email, idade, genero);
    }else{
        alert("Preencha todos os campos!");
    }
}

function ComunicacaoServidor(nome, senha, email, idade, genero){
    let senha_hash_md5 = $.MD5(senha);
	$.ajax({ 
		type:"POST", 
		url:"../php/login.php",
		data: {
            ch_nome:nome,
            ch_senha:senha_hash_md5,
            ch_email: email,
            ch_idade:idade,
            ch_genero: genero
        },
        success:function(resposta){
            if(resposta == '"Cadastrado"'){
                sucesso();
            }else{
                alert('Dados incorretos')
            }
        },
        error:function(jqXHR, exception){
            console.log(`erro: ${jqXHR.status}`);
            console.log(`erro: ${exception}`);
            console.log(jqXHR)
        }
	});
}

function sucesso(){
    window.location.href = "../paginas/sucesso.html";
}